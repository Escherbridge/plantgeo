from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
SERVICE = ROOT / 'services/agri-data-service'
OUT = ROOT / '.omc/verification/botanical-integrated-20260911'
NODE = Path('C:/Program Files/nodejs/node.exe')
NPM = NODE.parent / 'node_modules/npm/bin/npm-cli.js'


def now():
    return datetime.now(timezone.utc).isoformat()


def assert_source_identity(head, allow_receipt=False):
    current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if current != head:
        raise RuntimeError('HEAD changed during the final verification batch')
    changed = subprocess.check_output(['git', 'diff', '--name-only', head, '--'],
                                      cwd=ROOT, text=True).splitlines()
    allowed = {'.omc/ultrapilot-state.json'}
    if allow_receipt:
        allowed.add('services/agri-data-service/QUALITY_RECEIPT.json')
    unexpected = [path for path in changed if path not in allowed]
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'],
                                        cwd=ROOT, text=True).splitlines()
    unexpected.extend(path for path in untracked if not path.startswith('.omc/'))
    if unexpected:
        raise RuntimeError('Uncommitted inputs invalidate source identity: ' + repr(unexpected))


def run(name, command, cwd, env):
    path = OUT / (name + '.log')
    started = now()
    timer = time.monotonic()
    print(json.dumps({'started': name, 'at': started}), flush=True)
    with path.open('wb') as output:
        process = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
    data = path.read_bytes()
    result = {'name': name, 'command': command, 'cwd': str(cwd), 'started_at': started,
              'finished_at': now(), 'duration_seconds': round(time.monotonic() - timer, 3),
              'exit_code': process.returncode, 'log': path.relative_to(ROOT).as_posix(),
              'log_bytes': len(data), 'log_sha256': hashlib.sha256(data).hexdigest()}
    (OUT / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result), flush=True)
    return result


def child_environment():
    env = os.environ.copy()
    for name in ['AGRI_TEST_DATABASE_URL', 'AGRI_CROSS_MAJOR_DATABASE_URL',
                 'PLANTGEO_TEST_DATABASE_URL', 'POSTGIS_TEST_DSN']:
        env.pop(name, None)
    return env


def frontend():
    env = child_environment()
    env['PATH'] = str(NODE.parent) + os.pathsep + env.get('PATH', '')
    results = []
    for script in ['check:data-boundary', 'type-check', 'lint', 'test']:
        result = run('frontend-' + script.replace(':', '-'),
                     [str(NODE), str(NPM), 'run', script], ROOT, env)
        results.append(result)
    return results


def python():
    env = child_environment()
    env['UV_NO_SYNC'] = '1'
    env['PYTHONPATH'] = str(SERVICE / 'src')
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTEST_ADDOPTS'] = '--junitxml=' + chr(39) + (OUT / 'python-junit.xml').as_posix() + chr(39)
    uv = shutil.which('uv')
    if not uv:
        raise RuntimeError('uv is unavailable')
    result = run('python-full', [uv, 'run', '--no-sync', 'python', 'scripts/check.py', '--write-receipt'], SERVICE, env)
    results = [result]
    if result['exit_code'] == 0:
        results.append(run('python-receipt-verify', [uv, 'run', '--no-sync', 'python',
                                                  'scripts/verify_quality_receipt.py'], SERVICE, env))
    return results


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / 'invocation.json').exists():
        raise SystemExit('Refusing to overwrite an existing final sweep')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    assert_source_identity(head)
    invocation = {'source_commit': head, 'source_tree': tree, 'started_at': now(),
                  'database_integration': 'four optional database environment variables removed',
                  'dependency_sync': False, 'python_import_root': str(SERVICE / 'src'),
                  'web_image_embedded_gates': 'Dockerfile runs its normal boundary, type, lint and test checks during image construction',
                  'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'source_identity': 'HEAD and tracked/untracked input checks before and after local gates'}
    (OUT / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n', encoding='utf-8')
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(frontend), pool.submit(python)]
        results = [result for future in futures for result in future.result()]
    assert_source_identity(head, allow_receipt=True)
    if all(result['exit_code'] == 0 for result in results):
        podman = shutil.which('podman')
        if not podman:
            raise RuntimeError('podman unavailable; image proofs remain open')
        env = child_environment()
        archive = OUT / 'source-context.tar'
        snapshot = OUT / 'image-context'
        subprocess.run(['git', 'archive', '--format=tar', '--output', str(archive), head],
                       cwd=ROOT, check=True)
        snapshot.mkdir(exist_ok=False)
        with tarfile.open(archive) as bundle:
            bundle.extractall(snapshot, filter='data')
        image_service = snapshot / 'services/agri-data-service'
        shutil.copyfile(SERVICE / 'QUALITY_RECEIPT.json', image_service / 'QUALITY_RECEIPT.json')
        archive_check = run('archived-source-receipt-verify',
                            [sys.executable, 'scripts/verify_quality_receipt.py'], image_service, env)
        results.append(archive_check)
        if archive_check['exit_code'] != 0:
            raise RuntimeError('Archived source differs from the verified quality receipt')
        images = [('web', snapshot, snapshot / 'Dockerfile'),
                  ('data-service', image_service, image_service / 'Dockerfile'),
                  ('job-executor', snapshot, snapshot / 'infra/job-executor/Dockerfile')]
        for name, context, dockerfile in images:
            tag = 'localhost/plantgeo-integration-' + name + ':' + head[:12]
            build = run('image-' + name,
                        [podman, 'build', '--label', 'org.opencontainers.image.revision=' + head,
                         '--tag', tag, '--file', str(dockerfile), str(context)], ROOT, env)
            results.append(build)
            if build['exit_code'] == 0:
                smoke = ([podman, 'run', '--rm', '--network', 'none', '--entrypoint', 'node',
                          tag, '--check', 'server.js'] if name == 'web' else
                         [podman, 'run', '--rm', '--network', 'none', tag, 'agri-service', '--help'])
                results.append(run('image-' + name + '-smoke', smoke, ROOT, env))
                results.append(run('image-' + name + '-identity',
                                   [podman, 'image', 'inspect', '--format', '{{.Id}}', tag], ROOT, env))
    assert_source_identity(head, allow_receipt=True)
    report = {**invocation, 'finished_at': now(), 'checks': results,
              'passed': all(result['exit_code'] == 0 for result in results)}
    (OUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'final_result': report}), flush=True)
    raise SystemExit(0 if report['passed'] else 1)
