# Weather source and shared-file handoff preparation

This is read-only preparation for the dedicated weather owner. Root must not apply these weather commits or duplicate the shared implementation now. The weather owner will rebase/rebuild both approved commits onto root's final clean post-botanical boundary, then implement its shared weather work. Root will later compose the returned immutable weather and intervention candidates before one new full sweep. The current frozen `416342fa5bea836e6a062549b87c2706f53ce45e` pins below are handoff input, not the final transfer authority. Root supplies the eventual base, ref, clean-state evidence and shared blobs after current image/evidence gates finish.

The parent reserves the MapView two-line intervention mount and intervention routers/components. Weather must coordinate any overlap, particularly `src/components/map/MapView.tsx` and `src/lib/server/trpc/routers/wildfire.ts`; a whole-file replacement from the weather base would discard newer unrelated work.

## Verified source and evidence pins

- Peer task: `01a09323-6f59-7822-9e6f-146892776749`; inspected worktree `C:/Users/atooz/.codex/worktrees/32be/plantgeo`.
- Base: `362422e3dffebb61a68fd4d7303234c3a14a43ed`.
- Implementation: `aab0dceb6fb76ff3164b440f4fa48da5748f88a9`, tree `3508af01613724c34b6211fe58c5007b68763c30`; its sole parent is the stated base.
- Approval documentation: `09450d2c5498fb3258bcb1cd690d75ea509887e4`; its sole parent is the implementation. It changes exactly the weather lane's `evidence/verification.json` and `independent-review.md`.
- All **27/27 committed source/support/test hashes** and **27/27 tested working-file hashes** match the peer's records. The approval commit preserves all 27 source blobs. The implementation changes **46 total files**, comprising those 27 declared files and 19 additional track/evidence/attribute files. It is not a 27-file total commit.
- Every implementation path was compared across the base, frozen candidate and peer implementation. No path has divergent changes in both the peer and `416342f`. This is a blob comparison, not an executed cherry-pick or shared implementation approval.
- The saved source capture is 14,575 bytes, SHA-256 `34812e5101395d607ca9c61454a0aee140dbc5628a052b2b276fc85f01e45186`. Its first 14,573 HTTP-response bytes hash to `6909f2b34b420fa34c4bd66c4e812e4f605b564dd7c3751139b570a33593297d`; PowerShell appended the final CRLF. The scoped `.gitattributes` is an additional source path and preserves capture bytes. Working versus committed hashes differ for the textual capture receipt as disclosed; both recorded domains match.
- The April 28 fixture's saved catalogue hash matches canonical `live-reinventory-20260911.json`: `c60c582102a8915437a45f72ca042f6218ae329af3fd8fb1d23199e724993295`. Its extracted gap ranges match, including `2021-11-27` through `2026-07-31`, and contain `2025-04-28`. This proves the saved catalogue state, not the original screenshot's painted frame.

The machine manifest is [weather-intake-preparation-20260911.json](weather-intake-preparation-20260911.json). It retains all 46 source path comparisons, the 27 two-domain hash records, the two approval changes, committed handoff/evidence hashes, and 55 inspected shared paths with base/candidate/source/approval blobs. At creation its SHA-256 is `89ac609f5705089f7257657f2b96d22b9e816fc44be6956311e8e1a31209b2a8`. All recorded pin inspections passed. This inspection hashed committed evidence; it does not claim recovery of every peer raw local log or rerun its tests.

## Every concrete shared path named in the handoff

All **14** concrete shared file references in `integration-handoff.md` resolve to paths already present in the existing **119-path inventory**. None of these named paths is missing from that inventory. Every listed runtime path is unchanged by the peer from its base; canonical changes must be preserved.

| Handoff name | Exact repository path |
| --- | --- |
| `layer-registry.ts` | `src/lib/map/layer-registry.ts` |
| `LayerManager.tsx` | `src/components/map/LayerManager.tsx` |
| `LayerTimeSlider.tsx` | `src/components/map/layer-panel/LayerTimeSlider.tsx` |
| `layer-render-contract.ts` | `src/lib/map/layer-render-contract.ts` |
| `layer-legends.ts` | `src/lib/map/layer-legends.ts` |
| `parquet-slider-capabilities.ts` | `src/lib/server/services/parquet-slider-capabilities.ts` |
| `wildfire.ts` | `src/lib/server/trpc/routers/wildfire.ts` |
| `app.py` | `services/agri-data-service/src/agri_data_service/app.py` |
| `agent/graph.py` | `services/agri-data-service/src/agri_data_service/agent/graph.py` |
| `tools.py` | `services/agri-data-service/src/agri_data_service/agent/tools.py` |
| `mcp_server.py` | `services/agri-data-service/src/agri_data_service/agent/mcp_server.py` |
| `prompts.py` | `services/agri-data-service/src/agri_data_service/agent/prompts.py` |
| `pipeline/parquet/lane_registry.py` | `services/agri-data-service/src/agri_data_service/pipeline/parquet/lane_registry.py` |
| `execution/job_executor_service.py` | `services/agri-data-service/src/agri_data_service/execution/job_executor_service.py` |

The handoff also requires a **new HTTP blueprint**, a **remote object-store adapter**, and **durable cooldown receipts** without assigning exact paths. `services/agri-data-service/src/agri_data_service/interface/http/weather_forecast.py` is a proposed blueprint path, not an existing or approved source file. The other new paths remain weather-owner design decisions.

Additional inspected surfaces outside the old 119-path inventory are explicitly flagged in the manifest:

- `services/agri-data-service/src/agri_data_service/ingest/{AGENTS.md,http.py,upstream_retry.py}`.
- `services/agri-data-service/src/agri_data_service/agent/botanical_species_profiles.py` and `interface/http/botanical_species_profiles.py` under the same Python package root.
- `src/lib/server/http/bounded-upstream.ts` and `src/stores/map-store.ts`.
- `conductor/{RUNBOOK.md,tracks.md}` and each weather track's `spec.md`, `plan.md`, `metadata.json`.

These are additional inventory scope, not evidence that the peer edited shared files. The prepared forecast modules themselves are covered by the source manifest and are not registrations.

## Composition requirements against the canonical source

1. **Relabel the existing sampled product.** Preserve toggle `weather`, lane `weather-observations` and forecast horizon 0. Change the registry label to **Sampled weather estimates**, with subtitle **Open-Meteo current-condition model estimates at sampled locations.** The current registry interface has no subtitle field, so its definition and `src/components/map/layer-panel/LayerRow.tsx` need coordinated presentation plumbing. Existing hover and legend text already distinguish model estimates and sparse support; retain the observed raw-point/aggregate-bin contract. Do not relabel `sensors`, invent provider run metadata, substitute reanalysis, or fill missing history.

2. **Preserve the newer reader correction and add the missing catalogue gate locally.** `416342f` already filters completed other-day weather results in `LayerManager.tsx`, reports the requested/drawn day, and binds `FireDetails.tsx` weather queries and captions to `useDebouncedLayerDay("weather")`. Its exact regression is named `clears the 2025-04-28 weather gap and rejects a delayed populated answer for another day`. Keep that regression and the separate fire incident clock. The remaining gate is stronger: proven selected-day catalogue unavailability must clear the sampled map/card frame even while an old placeholder or request is outstanding. `useLayerRenderState` currently makes availability advisory and deliberately treats unknown catalogue state as published; `shouldRender` ignores day availability. Do not globally change that shared rule for all layers. Add a weather-scoped known-evidence gate and explicit unavailable state, retaining the distinction between unknown, gap, governed absence and provider outage. The peer's older reconciliation describes pre-correction code and needs a current handoff addendum.

3. **Own separate Now, History and Forecast state.** The existing generic slider is day based and supplies no forecast run/place/hour owner. Keep the observations' selected day and server-today live-edge semantics. Introduce an explicit forecast owner for product, immutable run, picked/search location, IANA timezone, half-open UTC window, selected valid hour, variable, zoom and field bounds. Never use viewport centre as a selected location. Abort superseded requests and bind cache keys to all relevant axes; a new run refreshes the entire series. Forecast must not answer History. Keep the new product `open-meteo-single-runs-ecmwf-ifs-sampled-v1` separate from `weather-observations`.

4. **Add validated bounded transports before mounting UI.** The peer supplies `read_selected_forecast` and `read_forecast_field` in `planes/weather_forecast.py`, but no HTTP blueprint, TypeScript transport or tRPC registration. Register the bounded blueprint through canonical `app.py` while preserving the botanical blueprint in both all-in-one and published-reader profiles. Add dedicated selected/field procedures and a response validator before data reaches the TypeScript mirror. Use the existing bounded transport patterns in `parquet-plane-client.ts` and `src/lib/server/http/bounded-upstream.ts`; enforce request/response bytes, row/sample/distance/window caps and explicit typed failure/absence states. Product/run identity must remain bound even for null-run absence responses. Do not route through legacy forecast SQL/scaffolding or PostgreSQL observations.

5. **Compose cards, sampled scalars and u/v honestly.** `WeatherDetails` takes `productId`, exact `ForecastSelection`, selected response and `validAt`; `WeatherFieldLayer` takes values/run/hour/variable; `WeatherWindLayer` needs paired u/v values for the same run, sample coordinates and hour. The field reader accepts one variable per call, so wind needs an explicit paired-component transport or atomically matched requests. A selected-location response is one bounded nearest sample, not the viewport field. Match card and field response context while retaining their distinct spatial queries. The prepared renderer caps each field at 2,000 points, whereas the reader can return 50,000 rows; surface overflow as a refusal before it becomes an unexplained empty map, and never silently thin support. Preserve UTC identity normalization, null-run absence behavior, style reload and removed-map cleanup. Register scalar legends from the exact browser variable vocabulary before enabling color. Support is sampled points and static downwind arrows; neither interpolated fields nor particles are admitted.

6. **Register one host-bound agent/MCP tool without replacing botanical dispatch.** The prepared tool name is `weather_forecast_at_selected_location`; its descriptor takes no model-controlled arguments. Bind `WeatherForecastContext` from the selected UI forecast owner through request/host context and graph execution. Current `AgentRequest` and `routes/agent_analysis.py` carry location and selected day but no forecast context. `agent/tools.py::WAREHOUSE_TOOLS` is the canonical registry consumed by `agent/llm.py::tool_schemas/tool_by_name` and the current MCP list/call implementation. Add the weather adapter there through the existing tool-object and recording contracts; preserve `species_information`, its nonspatial release identity, and botanical ledger hooks. The standalone MCP transport also needs an explicit host-context mechanism or a typed refusal when no picked/search forecast context exists. Do not expose a tool that silently takes model coordinates, the viewport or current weather as a substitute.

7. **Use the canonical Retry-After work already present.** The current `ingest/http.py` has `BoundedResponse.retry_after` and bounded header capture. The peer handoff's statement that the shared helper drops the header applies to its older base. The new `weather_forecast/source.py::fetch_single_run` still discards the canonical field by raising `UpstreamHttpError(response.status)`. Preserve the existing shared transport change; adapt the forecast caller to a reviewed durable cooldown/deferral receipt and scheduler ownership before enabling provider retries. Generic capture is not yet forecast cooldown, and HTTP status/provider refusal is not a missing forecast value.

8. **Keep publication/catalogue/scheduler admission explicit.** The supplied source adapter validates one ECMWF IFS midnight sample and 240 hourly instants. The local artifact protocol uses trusted filesystem storage and immutable publication receipts; it is not a remote writer, production admission or active availability. A forecast capability must index actual published immutable runs and valid times. Daily observed-lane APIs in `lane_registry.py` and `job_executor_service.py` need an accepted run/valid-time contract before separate forward discovery/publication, work-authoring repair and coverage/status duties can be registered. Remote immutable storage, conditional pointers, retention/repair budgets, operator rollback, provider entitlement, source/domain census and acceptance remain open. Do not advertise a ten-day published horizon merely because the fixture has 240 hours.

## Validation boundaries and next evidence

Peer frontend evidence records **2,162 passed, 13 skipped, 145 passed files and 2 skipped files**, including **11 weather tests**; boundary/typecheck/lint/test process exits are zero. Its lint record contains **542 warnings**. This is the peer's result, not a warning count for the active canonical sweep.

Peer Python final format/lint/mypy passed, followed by **114 focused passing tests**, including the two cases that had failed for environment reasons in the broader recovery. That broader run records **6,086 passed, 149 skipped, one xfailed and two environmental failures**. The earlier initial run records **5,561 passed, 147 skipped, one xfailed and 529 temporary-directory setup errors**. Preserve all of these stages. The focused run is **not a full pytest rerun**, and the selector records `receipt_eligible: false`: **there is no official full Python quality receipt for this peer batch**.

The cmd recovery wrappers' final `TYPE` display used forward slashes and failed after writing result JSON. The stored `quality_exit`/`tests_exit` are immediately captured Python exits; committed quality/test output confirms them. This does not turn the entire wrapper invocation into a success. The independent approval covers the isolated modules and source fixture only; it excludes shared integration, production admission/publication, deployment and archival.

The active canonical sweep is separate. Root reported 1,084 host lint warnings because it also scanned the retained first image context under `.omc`; the earlier canonical warning baseline was 542. This read-only weather packet makes no final canonical receipt claim and does not alter the scratch closeout generator. Root owns that disclosure and eventual runner-context relocation.

After root transfers the final clean boundary, weather owns shared implementation and updated immutable source/review evidence. The returned candidate must retain the exact missing-day/late-response regression, add catalogue-before-response and mode/run/place cancellation assertions, validate new transport/refusal and agent/MCP identity behavior, and preserve botanical dispatch and intervention reservations. Root then composes the immutable weather and intervention candidates and runs the authorized combined sweep once. Both weather tracks remain active/in progress and not archive-ready. No source fetch, publication, scheduler activation, production operation, tracked edit or external task message occurred in this preparation lane.
