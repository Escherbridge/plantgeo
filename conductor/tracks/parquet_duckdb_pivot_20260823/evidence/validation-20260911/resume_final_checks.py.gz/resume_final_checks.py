from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_checks', HERE / 'run_final_checks.py')
checks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checks)
ROOT, SERVICE, OUT = checks.ROOT, checks.SERVICE, checks.OUT


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    if (OUT / 'result.json').exists() or (OUT / 'resume-invocation.json').exists():
        raise RuntimeError('Refusing to overwrite a completed or started continuation')
    invocation = json.loads((OUT / 'invocation.json').read_text(encoding='utf-8'))
    original_hash = hashlib.sha256((HERE / 'run_final_checks.py').read_bytes()).hexdigest()
    if original_hash != invocation['runner_sha256']:
        raise RuntimeError('Original runner changed')
    results = []
    for name in ['frontend-check-data-boundary', 'frontend-type-check', 'frontend-lint',
                 'frontend-test', 'python-full', 'python-receipt-verify']:
        record = json.loads((OUT / (name + '.json')).read_text(encoding='utf-8'))
        data = (ROOT / record['log']).read_bytes()
        if (record['exit_code'] != 0 or len(data) != record['log_bytes']
                or hashlib.sha256(data).hexdigest() != record['log_sha256']):
            raise RuntimeError('Failed or changed prior gate: ' + name)
        results.append(record)
    source = SERVICE / 'Usersatooz.codexworktrees4ccbplantgeo.omcverificationactive-track-integration-20260911python-junit.xml'
    target = OUT / 'python-junit.xml'
    for path in [source, target]:
        if not path.resolve().is_relative_to(ROOT.resolve()):
            raise RuntimeError('JUnit relocation is outside the workspace')
    if target.exists():
        raise RuntimeError('JUnit destination already exists')
    raw = source.read_bytes()
    xml = ET.fromstring(raw)
    cases = xml.findall('.//testcase')
    if not cases or any(case.find('failure') is not None or case.find('error') is not None for case in cases):
        raise RuntimeError('Unexpected JUnit contents')
    recovery = {
        'original_wrapper_exit_code': 1,
        'original_stop': 'Source identity guard rejected the generated JUnit report at a malformed Windows relative path after all six local gates passed.',
        'cause': 'PYTEST_ADDOPTS applies shell-like parsing to an unquoted Windows path; backslashes were consumed.',
        'junit_original_path': source.relative_to(ROOT).as_posix(),
        'junit_retained_path': target.relative_to(ROOT).as_posix(),
        'junit_bytes': len(raw), 'junit_sha256': hashlib.sha256(raw).hexdigest(),
        'junit_cases': len(cases), 'started_at': checks.now(),
        'continuation_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'tests_repeated': False,
    }
    source.rename(target)
    if target.read_bytes() != raw:
        raise RuntimeError('JUnit relocation changed bytes')
    checks.assert_source_identity(invocation['source_commit'], allow_receipt=True)
    save('resume-invocation.json', recovery)
    error = None
    try:
        podman = shutil.which('podman')
        if not podman:
            raise RuntimeError('podman unavailable')
        env = checks.child_environment()
        archive, snapshot = OUT / 'source-context.tar', OUT / 'image-context'
        if archive.exists() or snapshot.exists():
            raise RuntimeError('Refusing to overwrite a prior image context')
        subprocess.run(['git', 'archive', '--format=tar', '--output', str(archive),
                        invocation['source_commit']], cwd=ROOT, check=True)
        snapshot.mkdir()
        with tarfile.open(archive) as bundle:
            bundle.extractall(snapshot, filter='data')
        image_service = snapshot / 'services/agri-data-service'
        shutil.copyfile(SERVICE / 'QUALITY_RECEIPT.json', image_service / 'QUALITY_RECEIPT.json')
        archive_check = checks.run('archived-source-receipt-verify',
                                  [sys.executable, 'scripts/verify_quality_receipt.py'], image_service, env)
        results.append(archive_check)
        if archive_check['exit_code'] != 0:
            raise RuntimeError('Archived source differs from verified receipt')
        for name, context, dockerfile in [
            ('web', snapshot, snapshot / 'Dockerfile'),
            ('data-service', image_service, image_service / 'Dockerfile'),
            ('job-executor', snapshot, snapshot / 'infra/job-executor/Dockerfile')]:
            tag = 'localhost/plantgeo-integration-' + name + ':' + invocation['source_commit'][:12]
            build = checks.run('image-' + name,
                               [podman, 'build', '--label', 'org.opencontainers.image.revision=' + invocation['source_commit'],
                                '--tag', tag, '--file', str(dockerfile), str(context)], ROOT, env)
            results.append(build)
            if build['exit_code'] == 0:
                smoke = ([podman, 'run', '--rm', '--network', 'none', '--entrypoint', 'node', tag, '--check', 'server.js']
                         if name == 'web' else [podman, 'run', '--rm', '--network', 'none', tag, 'agri-service', '--help'])
                results.append(checks.run('image-' + name + '-smoke', smoke, ROOT, env))
                results.append(checks.run('image-' + name + '-identity',
                                          [podman, 'image', 'inspect', '--format', '{{.Id}}', tag], ROOT, env))
        checks.assert_source_identity(invocation['source_commit'], allow_receipt=True)
    except Exception as exc:
        error = type(exc).__name__ + ': ' + str(exc)
    report = {**invocation, 'finished_at': checks.now(), 'checks': results,
              'continuation': recovery, 'continuation_error': error,
              'passed': error is None and len(results) == 16 and all(r['exit_code'] == 0 for r in results)}
    save('result.json', report)
    print(json.dumps({'passed': report['passed'], 'continuation_error': error,
                      'source_commit': report['source_commit'], 'checks': len(results)}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
